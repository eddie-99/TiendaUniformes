package com.example.pantallas_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class CatalogoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalogo);
    }

    public void openMain4(View view) {startActivity(new Intent(this, LoginActivity.class));}

    public void openMainC1(View view) {startActivity(new Intent(this, ScrollCatalogoActivity.class));}
    public void openMainC2(View view) {startActivity(new Intent(this, ScrollCatalogoActivity.class));}

    public void openMainC3(View view) {startActivity(new Intent(this, ScrollCatalogoActivity.class));}

    public void openMainC4(View view) {startActivity(new Intent(this, ScrollCatalogoActivity.class));}

    public void openMainCC(View view) {startActivity(new Intent(this, CarritoActivity.class));}
}