package com.example.pantallas_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class DetallesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles);
    }

    public void OpenMainAC(View view) {startActivity(new Intent(this, CarritoActivity.class));}

    public void OpenMain3(View view) {startActivity(new Intent(this, CatalogoActivity.class));}
}