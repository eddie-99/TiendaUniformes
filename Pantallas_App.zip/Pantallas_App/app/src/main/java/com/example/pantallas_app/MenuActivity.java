package com.example.pantallas_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }

    public void openMain3(View view) {startActivity(new Intent(this, LoginActivity.class));}

    public void openMainAP(View view) {startActivity(new Intent(this, AgregarActivity.class));}

    public void openMainCP(View view) {startActivity(new Intent(this, ConsultaActivity.class));}

    public void openMainEP(View view) {startActivity(new Intent(this, EliminarActivity.class));}

    public void openMainAcP(View view) {startActivity(new Intent(this, ActualizarActivity.class));}
}